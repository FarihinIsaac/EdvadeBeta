const ANNOUNCEMENT_KEY = "edvade_announcement";

function getAnnouncement() {
  const raw = localStorage.getItem(ANNOUNCEMENT_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (err) {
    return null;
  }
}

function saveAnnouncement({ title, message }) {
  const user = JSON.parse(localStorage.getItem("user") || "{}") || {};
  const announcement = {
    title: String(title || "").trim() || "Announcement",
    message: String(message || "").trim(),
    author: user.name || "Lecturer",
    publishedAt: new Date().toISOString()
  };
  localStorage.setItem(ANNOUNCEMENT_KEY, JSON.stringify(announcement));
  return announcement;
}

function renderAnnouncement(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const announcement = getAnnouncement();
  container.innerHTML = "";

  if (!announcement || !announcement.message) {
    const empty = document.createElement("div");
    empty.className = "announcement-empty";
    empty.textContent = "No announcements yet. Your lecturer will share one here soon.";
    container.appendChild(empty);
    return;
  }

  const card = document.createElement("div");
  card.className = "announcement-card";

  const header = document.createElement("div");
  header.className = "announcement-header";

  const title = document.createElement("strong");
  title.textContent = announcement.title;
  const meta = document.createElement("span");
  meta.textContent = `Posted ${new Date(announcement.publishedAt).toLocaleString()}`;
  header.appendChild(title);
  header.appendChild(meta);

  const body = document.createElement("p");
  body.textContent = announcement.message;
  body.className = "announcement-body";

  const footer = document.createElement("div");
  footer.className = "announcement-footer";
  footer.textContent = `By ${announcement.author}`;

  card.appendChild(header);
  card.appendChild(body);
  card.appendChild(footer);
  container.appendChild(card);
}

function initAnnouncementEditor(formId, titleId, messageId, statusId, previewId) {
  const form = document.getElementById(formId);
  if (!form) return;

  const titleInput = document.getElementById(titleId);
  const messageInput = document.getElementById(messageId);
  const status = document.getElementById(statusId);
  const preview = document.getElementById(previewId);

  const existing = getAnnouncement();
  if (existing) {
    if (titleInput) titleInput.value = existing.title;
    if (messageInput) messageInput.value = existing.message;
  }

  if (preview) renderAnnouncement(previewId);

  form.addEventListener("submit", event => {
    event.preventDefault();

    if (!titleInput || !messageInput) return;
    if (!messageInput.value.trim()) {
      alert("Please type an announcement message before publishing.");
      return;
    }

    saveAnnouncement({
      title: titleInput.value,
      message: messageInput.value
    });

    if (status) {
      status.textContent = "Announcement published successfully.";
      setTimeout(() => { status.textContent = ""; }, 3000);
    }

    if (previewId) {
      renderAnnouncement(previewId);
    }
    renderAnnouncement("announcementWidget");
    renderAnnouncement("homeAnnouncementWidget");
  });
}
